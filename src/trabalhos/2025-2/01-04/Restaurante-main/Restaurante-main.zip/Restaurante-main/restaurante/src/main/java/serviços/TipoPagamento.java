package serviços;

public enum TipoPagamento{
    DINHEIRO, CARTAO_CREDITO, CARTAO_DEBITO, PIX;
}
