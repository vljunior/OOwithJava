package iterface;

public interface Pagavel {
    double calcularPagamento();
}