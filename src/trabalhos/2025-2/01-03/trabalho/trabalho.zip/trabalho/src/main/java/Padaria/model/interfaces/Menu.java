package Padaria.model.interfaces;


public interface Menu {
    
    void executarMenu();
    

    void exibirCabecalho();
    

    void exibirOpcoes();
    
    
    void processarOpcao(int opcao);
}